﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    public class Utilizador
    {
        #region Atributos
        /// <summary>
        /// Representa um produto no sistema de comércio eletrônico.
        /// </summary>

        int id;
        string nome;
        string email;
        string nTelemovel;
        #endregion

        #region Construtor
        /// <summary>
        /// Construtor da classe base
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nome"></param>
        /// <param name="email"></param>
        /// <param name="ntelemovel"></param>
        public Utilizador(int id, string nome, string email, string ntelemovel)
        {
            Id = id; // Atribui o ID fornecido
            Nome = nome; // Atribui o nome fornecido
            Email = email; // Atribui o email fornecido
            nTelemovel = ntelemovel;    
        }
        #endregion

        #region Properties
        /// <summary>
        /// Região que agrupa as propriedades (getters e setters) da classe
        /// </summary>
        // Propriedades comuns a todos os utilizadores
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string NTelemovel
        {
            get { return nTelemovel; }
            set { nTelemovel = value; }
        }

        #endregion

        #region Metodos
        /// <summary>
        /// Atualiza o e-mail e o número de telemóvel do utilizador.
        /// </summary>
        /// <param name="novoEmail">O novo e-mail do cliente.</param>
        /// <param name="novoTelemovel">O novo número de telemóvel do cliente.</param>
        public bool AtualizarContato(string novoEmail, string novoTelemovel)
        {
            this.email = novoEmail;
            this.nTelemovel = novoTelemovel;
            return true;
        }
        #endregion
    }





}
