var searchData=
[
  ['naopodeinserir_0',['NaoPodeInserir',['../class_excecoes_lib_1_1_nao_pode_inserir.html',1,'ExcecoesLib']]],
  ['naopodeinserirutilizador_1',['NaoPodeInserirUtilizador',['../class_excecoes_lib_1_1_nao_pode_inserir_utilizador.html',1,'ExcecoesLib']]]
];
