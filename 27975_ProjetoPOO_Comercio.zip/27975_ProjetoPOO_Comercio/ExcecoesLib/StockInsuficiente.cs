﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcecoesLib
{
    /// <summary>
    /// Exceção para quando um produto não tiver stock suficiente
    /// </summary>
    public class StockInsuficiente :ApplicationException
    {
        /// <summary>
        /// Construtor sem parâmetros, com uma mensagem padrão.
        /// </summary>
        public StockInsuficiente() : base("Stock insuficiente para o produto.") { }

        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada.
        /// </summary>
        /// <param name="mensagem"></param>
        public StockInsuficiente(string mensagem) : base(mensagem) { }
 
        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada e uma exceção interna.
        /// </summary>
        /// <param name="mensagem"></param>
        /// <param name="inner"></param>
        public StockInsuficiente(string mensagem, Exception inner) : base(mensagem, inner) { }
    

}
}
