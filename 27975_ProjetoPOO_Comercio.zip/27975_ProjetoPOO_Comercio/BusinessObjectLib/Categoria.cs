﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    public class Categoria
    {
        #region Atributos 
        /// <summary>
        /// Representa um produto no sistema de comércio eletrônico.
        /// </summary>

        int idCategoria;
        string nomeCategoria;
       
        #endregion

        #region Construtor
        /// <summary>
        /// Construtor padrão da classe Produto.
        /// </summary>
        public Categoria(int id, string nome)
        {
            this.idCategoria = idCategoria;
            this.nomeCategoria = nomeCategoria;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Região que agrupa as propriedades (getters e setters) da classe
        /// </summary>
        public int Id
        {
            get { return idCategoria; }
            set { idCategoria = value; }
        }
        public string Nome
        {
            get { return nomeCategoria; }
            set { nomeCategoria = value; }
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Atualiza o nome da categoria.
        /// </summary>
        /// <param name="novoNome">O novo nome da categoria.</param>
        public bool AtualizarNome(string novoNome)
        {
            this.nomeCategoria = novoNome;
            return true;    
        }

        #endregion
    }
}
