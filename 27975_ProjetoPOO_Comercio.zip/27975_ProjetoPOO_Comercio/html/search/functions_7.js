var searchData=
[
  ['pedido_0',['Pedido',['../class_business_object_1_1_pedido.html#a97a4427f939cabbc296a7bfae43c16fb',1,'BusinessObject::Pedido']]],
  ['pedidossemproduto_1',['PedidosSemProduto',['../class_excecoes_lib_1_1_pedidos_sem_produto.html#aa66ada947169d78d88ed29c2bf6d42af',1,'ExcecoesLib.PedidosSemProduto.PedidosSemProduto()'],['../class_excecoes_lib_1_1_pedidos_sem_produto.html#a402ec7ff974cecefc8a39de671c96122',1,'ExcecoesLib.PedidosSemProduto.PedidosSemProduto(string mensagem)'],['../class_excecoes_lib_1_1_pedidos_sem_produto.html#a54c5ffc085a90675d47cf13ac142c19d',1,'ExcecoesLib.PedidosSemProduto.PedidosSemProduto(string mensagem, Exception inner)']]],
  ['precoinvalido_2',['PrecoInvalido',['../class_excecoes_lib_1_1_preco_invalido.html#a56d7120a1ed36a4c55f18652168baae9',1,'ExcecoesLib.PrecoInvalido.PrecoInvalido()'],['../class_excecoes_lib_1_1_preco_invalido.html#a8df71bfd0c4b98cf44da716702a50e57',1,'ExcecoesLib.PrecoInvalido.PrecoInvalido(string mensagem)'],['../class_excecoes_lib_1_1_preco_invalido.html#a048b64190dfcb8e71ece6c2b7a9ff485',1,'ExcecoesLib.PrecoInvalido.PrecoInvalido(string mensagem, Exception inner)']]],
  ['produto_3',['Produto',['../class_business_object_1_1_produto.html#afc77b489cbbe3265a24532dec04988a9',1,'BusinessObject::Produto']]]
];
