﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    public class Cliente : Utilizador
    {
        #region Atributos
        // Classe 
        /// <summary>
        /// Representa um produto no sistema de comércio eletrônico.
        /// </summary>

        int idCliente;
        string nome;
        string email;
        string nTelemovel;
        string nContribuinte;
        string endereco;

        #endregion

        #region Construtor
        /// <summary>
        /// Construtor padrão da classe Produto.
        /// Subclasse Cliente que herda de Utilizador
        /// </summary>
        public Cliente(int idCliente, string nome, string email, string nTelemovel, string nContribuinte) 
            : base(idCliente, nome, email, nTelemovel) // Chamada ao construtor da classe base
        {
            this.idCliente = idCliente;
            this.nome = nome;
            this.email = email;
            this.nTelemovel = nTelemovel;
            this.nContribuinte = nContribuinte;

            Endereco = endereco; // Atribui o endereço fornecido
        }


        #endregion

        #region Properties
        /// <summary>
        /// Região que agrupa as propriedades (getters e setters) da classe
        /// </summary>
        public int Id
        {
            get { return idCliente; }
            set { idCliente = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Email 
        { 
            get { return email; } 
            set { email = value; } 
        }
        public string NTelemovel
        {
            get { return nTelemovel; }
            set { nTelemovel = value; }
        }

        public string NContribuinte
        {
            get { return nContribuinte; }
            set { nContribuinte = value; }
        }


        public string Endereco {
            get { return endereco; }
            set { endereco = value; }
        }
        #endregion

        #region Metodos

        /// <summary>
        /// Atualiza o e-mail e o número de telemóvel do cliente.
        /// </summary>
        /// <param name="novoEmail">O novo e-mail do cliente.</param>
        /// <param name="novoTelemovel">O novo número de telemóvel do cliente.</param>
        public bool AtualizarContato(string novoEmail, string novoTelemovel)
        {
            this.email = novoEmail;
            this.nTelemovel = novoTelemovel;
            return true;
        }

        #endregion
    }
}
