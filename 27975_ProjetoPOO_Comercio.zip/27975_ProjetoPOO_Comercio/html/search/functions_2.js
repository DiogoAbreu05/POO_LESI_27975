var searchData=
[
  ['existe_0',['Existe',['../class_listas_lib_1_1_clientes.html#a74518c696a1bbe944bb415f4137fc402',1,'ListasLib.Clientes.Existe()'],['../class_listas_lib_1_1_pedidos.html#a744b9e1d91ad8042f3b8efdaa3966a61',1,'ListasLib.Pedidos.Existe()'],['../class_listas_lib_1_1_produtos.html#a7088c74704e338cb12da9f700b27f219',1,'ListasLib.Produtos.Existe()'],['../class_listas_lib_1_1_utilizadores.html#a1f3687e6c27b1985e78d52abde9fbff3',1,'ListasLib.Utilizadores.Existe()']]]
];
