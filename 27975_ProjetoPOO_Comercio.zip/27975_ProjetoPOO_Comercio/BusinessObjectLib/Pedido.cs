﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessObject
{
    public class Pedido
    {
        #region Atributos
        /// <summary>
        /// Representa um pedido no sistema de comércio eletrônico.
        /// </summary>

        int idPedido;// Atributo que armazena o identificador único do pedido.
        string produtoPedido;// Atributo que armazena o nome do produto associado ao pedido.
        string cliente;// Atributo que armazena o nome do cliente que fez o pedido.
        string estadoDaEncomenda; // Atributo que armazena o estado atual do pedido (ex.: pendente, enviado).
        string dataEncomenda; // Atributo que armazena a data em que o pedido foi realizado.
        int valorEncomenda;// Atributo que armazena o valor total do pedido (sem imposto).
        string moradaAEnviar;// Atributo que armazena o endereço para onde o pedido deve ser enviado.
        #endregion

        #region Construtor
        /// <summary>
        /// Construtor padrão da classe Produto.
        /// </summary>
        public Pedido(int idPedido, string produtoPedido,string cliente,string estadoDaEncomenda,string dataEncomenda,int valorEncomenda,string moradaAEnviar)
        {
            // Atribui o valor do parâmetro ao atributo correspondente da classe.
            this.idPedido = idPedido;
            this.produtoPedido = produtoPedido;
            this.cliente = cliente;
            this.estadoDaEncomenda = estadoDaEncomenda;
            this.dataEncomenda = dataEncomenda;
            this.valorEncomenda = valorEncomenda;
            this.moradaAEnviar = moradaAEnviar;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Região que agrupa as propriedades (getters e setters) da classe
        /// </summary>
        /// 
                
        public int Id
        {
            get { return idPedido; }
            set { idPedido = value; }
        }
        public string ProdutoPedido
        {
            get { return produtoPedido; }
            set { produtoPedido = value; }
        }
        public string Cliente
        {
            get { return cliente; }
            set { cliente = value; }
        }
        public string EstadoDaEncomenda
        {
            get { return estadoDaEncomenda; }
            set { estadoDaEncomenda = value; }
        }
        public int ValorEncomenda
        {
            get { return valorEncomenda; }
            set { valorEncomenda = value; }
        }
        public string MoradaAEnviar
        {
            get { return moradaAEnviar; }
            set { moradaAEnviar = value; }
        }

        public string DataEncomenda
        {
            get { return dataEncomenda; }
            set { dataEncomenda = value; }
        }
        #endregion

        #region Metodos

        /// <summary>
        /// Atualiza o estado da encomenda.
        /// </summary>
        /// <param name="novoEstado">Novo estado da encomenda.</param>
        public bool AtualizarEstadoEncomenda(string novoEstado)
        {
            this.estadoDaEncomenda = novoEstado; // Atualiza o atributo estadoDaEncomenda com o novo estado fornecido.
            return true;
        }

        /// <summary>
        /// Calcula o valor total da encomenda incluindo imposto.
        /// </summary>
        /// <param name="taxaImposto">Taxa de imposto a ser aplicada (em decimal, por exemplo, 0.20 para 20%).</param>
        /// <returns>Valor total da encomenda com imposto.</returns>
        public int CalcularValorComImposto(double taxaImposto)
        {
            return (int)(valorEncomenda * (1 + taxaImposto)); // Calcula o valor total da encomenda com imposto e retorna o valor arredondado para inteiro.
        }

        #endregion

    }
}
