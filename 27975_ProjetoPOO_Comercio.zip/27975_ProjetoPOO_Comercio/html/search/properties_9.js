var searchData=
[
  ['valorencomenda_0',['ValorEncomenda',['../class_business_object_1_1_pedido.html#a5b14f28b45a9272f9d238776297a152e',1,'BusinessObject::Pedido']]]
];
