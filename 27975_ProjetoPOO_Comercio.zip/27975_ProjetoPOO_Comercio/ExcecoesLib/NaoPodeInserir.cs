﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcecoesLib
{
    public class NaoPodeInserir: ApplicationException
    {
        /// <summary>
        /// Construtor padrão com uma mensagem fixa.
        /// </summary>
        public NaoPodeInserir() : base("impossivel") { }
        /// <summary>
        /// Construtor que recebe uma mensagem personalizada.
        /// </summary>
        /// <param name="msg"></param>
        /// <exception cref="Exception"></exception>
        public NaoPodeInserir(string msg)
        {
            throw new Exception(msg + "Nem penses");
        }

        /// <summary>
        /// Construtor que recebe uma exceção e relança com a mensagem personalizada.
        /// </summary>
        /// <param name="e"></param>
        /// <exception cref="NaoPodeInserir"></exception>
        public NaoPodeInserir(Exception e)
        {
            throw new NaoPodeInserir(e.Message);
        }
    }
}
