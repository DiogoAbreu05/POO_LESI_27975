﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BusinessObject; 
using ListasLib; 
using ExcecoesLib; 

namespace RegrasLib
{
    /// <summary>
    ///  Classe responsável por encapsular regras de negócio relacionadas a pedidos
    /// </summary>
    public class RegraPedido
    {
        /// <summary>
        ///  Método para validar se um pedido não está vazio
        /// </summary>
        /// <param name="pedido"></param>
        /// <returns></returns>
        public static bool ValidarPedidoNaoVazio(Pedido pedido)
        {
            return pedido.ProdutoPedido != null ;
        }

        // Método comentado que poderia calcular o valor total de um pedido
        // Parâmetros:
        // - Pedido pedido: Objeto do tipo Pedido
        // Retorno:
        // - Valor total calculado com base no preço e quantidade de cada produto
        // public static double CalcularValorTotal(Pedido pedido)
        // {
        //     // Retorna a soma do preço multiplicado pela quantidade de cada produto
        //     // return pedido.ProdutoPedido.Sum(p => p.Preco * p.Quantidade);
        // }
    }
}
