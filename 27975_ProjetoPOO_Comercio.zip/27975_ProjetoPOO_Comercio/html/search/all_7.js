var searchData=
[
  ['garantiameses_0',['GarantiaMeses',['../class_business_object_1_1_produto.html#a96cb4b1c780979fcc8ed694febb19a86',1,'BusinessObject::Produto']]],
  ['guardarparaficheiro_1',['GuardarParaFicheiro',['../class_listas_lib_1_1_clientes.html#acc5cc5e302959751a280b9aa57c9552e',1,'ListasLib.Clientes.GuardarParaFicheiro()'],['../class_listas_lib_1_1_pedidos.html#ae85f9a8221c641c596c1506b56c9c9b0',1,'ListasLib.Pedidos.GuardarParaFicheiro()'],['../class_listas_lib_1_1_produtos.html#a980d2138f22f1a0fe4de84d984e765f4',1,'ListasLib.Produtos.GuardarParaFicheiro()'],['../class_listas_lib_1_1_utilizadores.html#acc896b039b2673e1ecdfee84497e27c8',1,'ListasLib.Utilizadores.GuardarParaFicheiro()']]]
];
