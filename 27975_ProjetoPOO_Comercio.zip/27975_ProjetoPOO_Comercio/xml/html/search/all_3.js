var searchData=
[
  ['descricao_0',['Descricao',['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#aaa00d42e53129082f4b49af8fa5a16a1',1,'_27975_ProjetoPOO_Comercio::Produto']]]
];
