﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BusinessObject;
using ListasLib;
using ExcecoesLib;
using System.Text.RegularExpressions;

namespace RegrasLib
{
    public class RegraUtilizador
    {
        public static bool InsereUtilizadorNosDados(Utilizador u)
        {
            try
            {
                // Chama um método fictício que adiciona o utilizador ao sistema.
                // Este método deve implementar as regras de negócio específicas.
                return Utilizadores.AdicionarUtilizador(u);
            }
            catch (NaoPodeInserir e) // Captura uma exceção específica para regras de inserção.
            {
                // Lança uma nova exceção com uma mensagem informativa e a regra violada.
                throw new Exception(e.Message + " Regra Violada");
            }
        }

    }
}
