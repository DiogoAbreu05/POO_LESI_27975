var searchData=
[
  ['id_0',['Id',['../class_business_object_1_1_categoria.html#accf563bcd6c36ee0db8b71728ffae085',1,'BusinessObject.Categoria.Id'],['../class_business_object_1_1_cliente.html#a537f65e421acdd0f4759b7b37fde9c10',1,'BusinessObject.Cliente.Id'],['../class_business_object_1_1_pedido.html#a238be8e9c343d24bc2866ab089d11081',1,'BusinessObject.Pedido.Id'],['../class_business_object_1_1_produto.html#a0e88c1a39056ce84cd810be0e1c0a5b3',1,'BusinessObject.Produto.Id'],['../class_business_object_1_1_utilizador.html#a9840d6e9bf0a3147b9f8b6fd1d830cd1',1,'BusinessObject.Utilizador.Id']]]
];
