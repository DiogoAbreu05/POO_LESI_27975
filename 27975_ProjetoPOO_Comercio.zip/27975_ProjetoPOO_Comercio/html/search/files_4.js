var searchData=
[
  ['naopodeinserir_2ecs_0',['NaoPodeInserir.cs',['../_nao_pode_inserir_8cs.html',1,'']]],
  ['naopodeinserirutilizador_2ecs_1',['NaoPodeInserirUtilizador.cs',['../_nao_pode_inserir_utilizador_8cs.html',1,'']]]
];
