var searchData=
[
  ['admin_0',['Admin',['../class_business_object_1_1_admin.html',1,'BusinessObject']]]
];
