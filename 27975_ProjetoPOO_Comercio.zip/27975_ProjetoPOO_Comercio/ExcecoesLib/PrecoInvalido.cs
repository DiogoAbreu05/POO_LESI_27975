﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcecoesLib
{
    /// <summary>
    /// Exceção para preços inválidos
    /// </summary>
    public class PrecoInvalido :ApplicationException
    {
        /// <summary>
        /// Construtor sem parâmetros, com uma mensagem padrão.
        /// </summary>
        public PrecoInvalido() : base("O preço do produto é inválido (deve ser maior que zero).") { }

        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada.
        /// </summary>
        /// <param name="mensagem"></param>
        public PrecoInvalido(string mensagem) : base(mensagem) { }

        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada e uma exceção interna.
        /// </summary>
        /// <param name="mensagem"></param>
        /// <param name="inner"></param>
        public PrecoInvalido(string mensagem, Exception inner) : base(mensagem, inner) { }
    }
}

