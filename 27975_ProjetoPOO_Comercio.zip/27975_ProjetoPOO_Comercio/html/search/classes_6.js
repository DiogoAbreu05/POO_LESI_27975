var searchData=
[
  ['stockinsuficiente_0',['StockInsuficiente',['../class_excecoes_lib_1_1_stock_insuficiente.html',1,'ExcecoesLib']]]
];
