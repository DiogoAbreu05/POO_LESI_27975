﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

using BusinessObject;

namespace ListasLib
{
    public class Produtos
    {
        // Lista de produtos no sistema
        private static List<Produto> listaProdutos;
        #region Contrututor
        /// <summary>
        /// Construtor que inicia a listaProdutos
        /// </summary>
        /// <param name="tamanho"></param>
        static Produtos()
        {
            listaProdutos = new List<Produto> ();
        }
        #endregion

        #region Metodos 
        /// <summary>
        ///  Adiciona um novo produto à lista
        /// </summary>
        /// <param name="produto"></param>
        public static bool AdicionarProduto(Produto produto)
        {
            try
            {
                listaProdutos.Add(produto);
                return true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
                return false;
            }
        }

        /// <summary>
        /// Remove uma Produtos da lista com base no ID.
        /// </summary>
        /// <param name="id">ID da Produtos a ser removida.</param>
        public static bool RemoverCategoria(int id)
        {
            // Procura a categoria com o ID especificado na lista.
            var categoria = listaProdutos.Find(c => c.Id == id);

            // Se encontrada, remove; caso contrário, exibe uma mensagem.
            if (categoria != null)
            {
                listaProdutos.Remove(categoria);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// Verifica se um Produto existe na lista pelo ID.
        /// </summary>
        /// <param name="id">ID Produto.</param>
        /// <returns>Verdadeiro se a produto existir; falso caso contrário.</returns>
        public static bool Existe(int id)
        {
            try
            {
                return listaProdutos.Exists(c => c.Id == id);
                return true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
                return false;
            }
        }

        /// <summary>
        /// Guardar a lista de produtos em um ficheiro.
        /// </summary>
        /// <param name="cdFile">Caminho do ficheiro onde os dados serão guardados.</param>
        public static void GuardarParaFicheiro(string cdFile)
        {
            // Cria um FileStream para manipular o ficheiro no caminho especificado
            FileStream f = new FileStream(@"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaprodutos.bin", FileMode.Create);

            // Cria um BinaryFormatter para serializar os dados em formato binário
            BinaryFormatter b = new BinaryFormatter();

            // Serializa o objeto "listaProdutos" e guarda no ficheiro
            b.Serialize(f, listaProdutos);
        }

        /// <summary>
        /// Carrega a lista de categorias de um ficheiro.
        /// </summary>
        /// <param name="cdFile">Caminho do ficheiro a ser carregado.</param>
        public static void CarregarDeFicheiro(string cdFile)
        {
            // Cria um FileStream para ler o ficheiro no caminho especificado
            FileStream f = new FileStream(@"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaProdutos.bin", FileMode.Open);

            // Cria um BinaryFormatter para desserializar os dados do ficheiro
            BinaryFormatter b = new BinaryFormatter();

            // Desserializa o conteúdo do ficheiro e atribui à variável "listaProdutos"
            listaProdutos = (List<Produto>)b.Deserialize(f);
        }
        #endregion
    }

}

