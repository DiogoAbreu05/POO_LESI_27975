var searchData=
[
  ['marca_0',['Marca',['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#a10877ee8882f5da2b42905e9a8a214ab',1,'_27975_ProjetoPOO_Comercio::Produto']]],
  ['moradaaenviar_1',['MoradaAEnviar',['../class__27975___projeto_p_o_o___comercio_1_1_pedido.html#ab77965930f2e86f07b5522d4edb9c91e',1,'_27975_ProjetoPOO_Comercio::Pedido']]]
];
