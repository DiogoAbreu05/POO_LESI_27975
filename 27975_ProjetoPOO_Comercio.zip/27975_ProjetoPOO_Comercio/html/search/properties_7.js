var searchData=
[
  ['preco_0',['Preco',['../class_business_object_1_1_produto.html#a0726ac940ee6486f7879eeefaa7a0a9c',1,'BusinessObject::Produto']]],
  ['produtopedido_1',['ProdutoPedido',['../class_business_object_1_1_pedido.html#acaeed6838f9b771ef4d81cc54b95a91c',1,'BusinessObject::Pedido']]]
];
