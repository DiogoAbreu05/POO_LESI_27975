var searchData=
[
  ['adicionarcliente_0',['AdicionarCliente',['../class_listas_lib_1_1_clientes.html#aee68849bdf5f5e81438a5fea0707149c',1,'ListasLib::Clientes']]],
  ['adicionarpedido_1',['AdicionarPedido',['../class_listas_lib_1_1_pedidos.html#ac77a6800225733274897ecb7210506e9',1,'ListasLib::Pedidos']]],
  ['adicionarproduto_2',['AdicionarProduto',['../class_listas_lib_1_1_produtos.html#a5e7bbfbfacc89a39b9097a03c777f8a5',1,'ListasLib::Produtos']]],
  ['adicionarutilizador_3',['AdicionarUtilizador',['../class_listas_lib_1_1_utilizadores.html#ad928d27c0d1a6f00d00bdc1f03982087',1,'ListasLib::Utilizadores']]],
  ['admin_4',['Admin',['../class_business_object_1_1_admin.html',1,'BusinessObject.Admin'],['../class_business_object_1_1_admin.html#a2d97b806e898b09e5381f7ad9826c35f',1,'BusinessObject.Admin.Admin()']]],
  ['admin_2ecs_5',['Admin.cs',['../_admin_8cs.html',1,'']]],
  ['asc_6',['Asc',['../namespace_business_object.html#a851dbd949fae82e95e33f54727287c27ae8338cca05b6a68b1b516f4f0d6b0a0f',1,'BusinessObject']]],
  ['assemblyinfo_2ecs_7',['AssemblyInfo.cs',['../_business_object_lib_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)'],['../_excecoes_lib_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)'],['../_listas_lib_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)'],['../_properties_2_assembly_info_8cs.html',1,'(Global Namespace)'],['../_regras_lib_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)']]],
  ['atualizarcontato_8',['AtualizarContato',['../class_business_object_1_1_cliente.html#a930577ec21ab629ae22e2fa83e74091d',1,'BusinessObject.Cliente.AtualizarContato()'],['../class_business_object_1_1_utilizador.html#a907498e51572fbd62e7da12e6db8ffc2',1,'BusinessObject.Utilizador.AtualizarContato()']]],
  ['atualizarestadoencomenda_9',['AtualizarEstadoEncomenda',['../class_business_object_1_1_pedido.html#a70d76fff0a1826b59285a18b18731817',1,'BusinessObject::Pedido']]],
  ['atualizarestadoencomenda_5fcomestadovazio_5fdevemanterestadoanterior_10',['AtualizarEstadoEncomenda_ComEstadoVazio_DeveManterEstadoAnterior',['../class_test_project_1_1_unit_test1.html#af6b7f0e68c394c85424b4a0f3f18ce98',1,'TestProject::UnitTest1']]],
  ['atualizarestadoencomenda_5fdeveatualizarestadocorretamente_11',['AtualizarEstadoEncomenda_DeveAtualizarEstadoCorretamente',['../class_test_project_1_1_unit_test1.html#a8ce382acc43eccf0cf555c696dc1821c',1,'TestProject::UnitTest1']]],
  ['atualizarnome_12',['AtualizarNome',['../class_business_object_1_1_categoria.html#a71617692c9eebc0268ca2a5e94038031',1,'BusinessObject::Categoria']]],
  ['atualizarstock_13',['AtualizarStock',['../class_business_object_1_1_produto.html#a5065ce3e0c1b4cf6981523982efdad75',1,'BusinessObject::Produto']]]
];
