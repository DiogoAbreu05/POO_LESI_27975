﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BusinessObject; // Biblioteca para objetos de negócios
using ListasLib; // Biblioteca para listas e coleções personalizadas
using ExcecoesLib; // Biblioteca para manipulação de exceções personalizadas

namespace RegrasLib
{
    /// <summary>
    /// Classe responsável por encapsular regras de negócio relacionadas a clientes
    /// </summary>
    public class RegraCliente
    {
        /// <summary>
        /// Método para inserir um cliente nos dados
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static bool InsereClienteNosDados(Cliente c)
        {
                try
                {
                // Tenta adicionar o cliente usando uma classe de suporte chamada "Clientes"
                return Clientes.AdicionarCliente(c);
                }
                catch (NaoPodeInserir e)
                {
                // Captura exceções específicas e lança uma nova com mensagem adicional
                throw new Exception(e.Message + "Regra Violada");
                }
        }
    }
}
