﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcecoesLib
{
    /// <summary>
    ///      Exceção para quando um cliente não for encontrado
    /// </summary>
    public class ClienteNaoEncontrado :ApplicationException
    {
        /// <summary>
        /// Construtor sem parâmetros, usando uma mensagem padrão.
        /// </summary>
        public ClienteNaoEncontrado() : base("Cliente não encontrado.") { }

        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada.
        /// </summary>
        /// <param name="mensagem"></param>
        public ClienteNaoEncontrado(string mensagem) : base(mensagem) { }

        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada e uma exceção interna.
        /// </summary>
        /// <param name="mensagem"></param>
        /// <param name="inner"></param>
        public ClienteNaoEncontrado(string mensagem, Exception inner) : base(mensagem, inner) { }
    }
}
