var searchData=
[
  ['quantidadeemstock_0',['QuantidadeEmStock',['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#a037c6a39163aa0cd4ed44581233e6648',1,'_27975_ProjetoPOO_Comercio::Produto']]]
];
