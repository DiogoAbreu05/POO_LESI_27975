var searchData=
[
  ['utilizador_0',['Utilizador',['../class__27975___projeto_p_o_o___comercio_1_1_utilizador.html',1,'_27975_ProjetoPOO_Comercio']]],
  ['utilizadores_1',['Utilizadores',['../class__27975___projeto_p_o_o___comercio_1_1_utilizadores.html',1,'_27975_ProjetoPOO_Comercio']]]
];
