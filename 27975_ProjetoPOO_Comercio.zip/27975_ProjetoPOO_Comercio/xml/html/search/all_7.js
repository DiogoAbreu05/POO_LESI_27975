var searchData=
[
  ['listarcategorias_0',['ListarCategorias',['../class__27975___projeto_p_o_o___comercio_1_1_categorias.html#a7e8a416f3c0a195fe8aecd831b8f67b0',1,'_27975_ProjetoPOO_Comercio::Categorias']]],
  ['listarclientes_1',['ListarClientes',['../class__27975___projeto_p_o_o___comercio_1_1_clientes.html#ae05d06adbe265ca9b7dac6be4e3a49fd',1,'_27975_ProjetoPOO_Comercio::Clientes']]],
  ['listarpedidos_2',['ListarPedidos',['../class__27975___projeto_p_o_o___comercio_1_1_pedidos.html#a440236b29b696dbfd025594fab288855',1,'_27975_ProjetoPOO_Comercio::Pedidos']]],
  ['listarutilizadores_3',['ListarUtilizadores',['../class__27975___projeto_p_o_o___comercio_1_1_utilizadores.html#aa68618cd08c5a04417b6204260cb1c2b',1,'_27975_ProjetoPOO_Comercio::Utilizadores']]]
];
