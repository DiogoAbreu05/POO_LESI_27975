var searchData=
[
  ['insereclientenosdados_0',['InsereClienteNosDados',['../class_regras_lib_1_1_regra_cliente.html#a82b73ccb857719712b34f69598bc4788',1,'RegrasLib::RegraCliente']]],
  ['insereutilizadornosdados_1',['InsereUtilizadorNosDados',['../class_regras_lib_1_1_regra_utilizador.html#a5b412eed02ebc6442695856ee3dba96e',1,'RegrasLib::RegraUtilizador']]]
];
