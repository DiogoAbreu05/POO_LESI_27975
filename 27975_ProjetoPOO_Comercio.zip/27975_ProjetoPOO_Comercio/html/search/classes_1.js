var searchData=
[
  ['categoria_0',['Categoria',['../class_business_object_1_1_categoria.html',1,'BusinessObject']]],
  ['cliente_1',['Cliente',['../class_business_object_1_1_cliente.html',1,'BusinessObject']]],
  ['clientenaoencontrado_2',['ClienteNaoEncontrado',['../class_excecoes_lib_1_1_cliente_nao_encontrado.html',1,'ExcecoesLib']]],
  ['clientes_3',['Clientes',['../class_listas_lib_1_1_clientes.html',1,'ListasLib']]]
];
