﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;

using BusinessObject;
using RegrasLib;
using ListasLib;
using ExcecoesLib;
using TestProject;


namespace _27975_ProjetoPOO_Comercio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region BusinessObject
            // Criação de Categorias
            Categoria categoria1 = new Categoria(1, "Smartphone");
            Categoria categoria2 = new Categoria(2, "Computadores Portateis");

            // Criação de Produtos
            Produto produto1 = new Produto(101, "Iphone 16", "Smartphone com câmera de alta resolução", 1200.00, categoria1.Nome, "Apple", 10, 24);
            Produto produto2 = new Produto(102, "Asus Vivobook", "O melhor computador para o desempenho do trabalhador/estudante", 850.00, categoria2.Nome, "Asus", 50, 24);

            // Criação de um cliente
            Cliente cliente1 = new Cliente(201, "Diogo Abreu", "diogo.abreu@gmail.com", "915345678", "123456789");
            cliente1.Endereco = "Rua da felicidade, 123";
            Cliente cliente2 = new Cliente(202, "Manuel Abreu", "manuel.abreu@gmail.com", "958222333", "123456789");
            cliente2.Endereco = "Rua da felicidade, 312";

            // Criação de um pedido
            Pedido pedido1 = new Pedido(301, produto1.Nome, cliente1.Nome, "Pendente", "2024-11-05", 1200, cliente1.Endereco);

            // Criação de um administrador
            Admin admin1 = new Admin(01, "ADMIN", "admin@gmail.com", "Administrador");

            // Criando e adicionando utilizadores
            Utilizador u1 = new Utilizador(1, "João Silva", "joao@gmail.com", "912345678");
            Utilizador u2 = new Utilizador(2, "Maria Oliveira", "maria@gmail.com", "923456789");

            #endregion

            #region Excecoes
            try
            {
                // Simulando exceção ClienteNaoEncontrado
                throw new ClienteNaoEncontrado();
            }
            catch (ClienteNaoEncontrado ex)
            {
                Console.WriteLine("Exceção: " + ex.Message);
            }

            try
            {
                // Simulando exceção NaoPodeInserir
                throw new NaoPodeInserir("Impossível inserir item.");
            }
            catch (NaoPodeInserir ex)
            {
                Console.WriteLine("Exceção: " + ex.Message);
            }

            try
            {
                // Simulando exceção NaoPodeInserirUtilizador
                throw new NaoPodeInserirUtilizador();
            }
            catch (NaoPodeInserirUtilizador ex)
            {
                Console.WriteLine("Exceção: " + ex.Message);
            }

            try
            {
                // Simulando exceção PedidosSemProduto
                throw new PedidosSemProduto();
            }
            catch (PedidosSemProduto ex)
            {
                Console.WriteLine("Exceção: " + ex.Message);
            }

            try
            {
                // Simulando exceção PrecoInvalido
                throw new PrecoInvalido("Preço do produto não pode ser menor que zero.");
            }
            catch (PrecoInvalido ex)
            {
                Console.WriteLine("Exceção: " + ex.Message);
            }

            try
            {
                // Simulando exceção StockInsuficiente
                throw new StockInsuficiente("Stock insuficiente para o produto X.");
            }
            catch (StockInsuficiente ex)
            {
                Console.WriteLine("Exceção: " + ex.Message);
            }
            #endregion

            #region Listas
            // Adiciona os clientes à lista
            Clientes.AdicionarCliente(cliente1);
            Clientes.AdicionarCliente(cliente2);

            // Verifica se os clientes existem
            Clientes.Existe(1);
            Clientes.Existe(3);

            // Remove um cliente
            bool removidocli = Clientes.RemoverCliente(2);

            // Tenta verificar se o cliente removido ainda existe
            Clientes.Existe(2);

            // Guarda a lista em um ficheiro bin
            string caminhocli = @"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaClientes.bin";
            Clientes.GuardarParaFicheiro(caminhocli);

            // Limpa a lista de clientes atual
            Clientes.CarregarDeFicheiro(caminhocli);
            

            /////Categorias
            Categorias.AdicionarCategoria(categoria1);
            Categorias.AdicionarCategoria(categoria2);

            // Verifica se as categorias existem
            Categorias.Existe(1);
            Categorias.Existe(3);

            // Remove uma categoria

            bool removidoca = Categorias.RemoverCategoria(1);


            // Verifica novamente se a categoria removida existe
            Categorias.Existe(1);

            // Guarda a lista em um ficheiro
            string caminhoca = @"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaCategorias.bin";
            Categorias.GuardarParaFicheiro(caminhoca);

            // Limpa a lista e carrega os dados do arquivo
            Categorias.CarregarDeFicheiro(caminhoca);


            ///PEDIDOS
            Pedidos.AdicionarPedido(pedido1);
            
            // Verifica se os pedidos existem
            Pedidos.Existe(101);

            // Remove um pedido
            bool removidope = Pedidos.RemoverPedidos(101);

            // Verifica novamente se o pedido removido existe
            Pedidos.Existe(101);

            // Guarda a lista em um ficheiro
            string caminhope = @"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaPedidos.bin";
            Pedidos.GuardarParaFicheiro(caminhope);

            // Limpa a lista de pedidos da memória
            Pedidos.CarregarDeFicheiro(caminhope);
        
            ////Produtos
            Produtos.AdicionarProduto(produto1);
            Produtos.AdicionarProduto(produto2);

            // Verifica se os produtos existem

            Produtos.Existe(101);
            Produtos.Existe(104);

            // Remove um produto
            bool removidopo = Produtos.RemoverCategoria(201);

            // Verifica novamente se o produto removido existe
            Produtos.Existe(201);

            // Guarda a lista em um ficheiro
            string caminhoPRO = @"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaProdutos.bin";
            Produtos.GuardarParaFicheiro(caminhoPRO);

            // Limpa a lista de produtos da memória
            Produtos.CarregarDeFicheiro(caminhoPRO);


            ////Utilizadores
            Utilizadores.AdicionarUtilizador(u1);
            Utilizadores.AdicionarUtilizador(u2);

            // Verifica se os utilizadores existem
            Utilizadores.Existe(301);
            Utilizadores.Existe(303);

            // Remove um utilizador
            bool removidou = Utilizadores.RemoverCategoria(301);


            // Verifica novamente se o utilizador removido existe
            Utilizadores.Existe(301);

            // Guarda a lista em um ficheiro
            string caminhoUt = @"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaUtilizadores.bin";

            // Limpa a lista de utilizadores da memória
            Utilizadores.CarregarDeFicheiro(caminhoUt);
            #endregion
            
            #region Compare
            List<Pedido> listaPedidos = pedidos;

            listaPedidos.Sort(new MyCompare(SortDirecc.Asc));
            Console.WriteLine("\nPedidos ordenados em ordem ascendente:");
            foreach (var itemPedido in listaPedidos)  
            {
                Console.WriteLine(itemPedido.ValorEncomenda); 
            }

            listaPedidos.Sort(new MyCompare(SortDirecc.Desc));
            Console.WriteLine("\nPedidos ordenados em ordem descendente:");
            foreach (var itemPedido in listaPedidos)  
            {
                Console.WriteLine(itemPedido.ValorEncomenda);  
            }
            #endregion
            
            #region Regras
            try
            {
                // Criar uma instância de Cliente com dados fictícios
                Cliente novoCliente = new Cliente(1, "João Silva", "joao.silva@email.com", "(11) 99999-9999", "112233444");
               

                // Tentando inserir o cliente usando RegraCliente
                bool sucesso = RegraCliente.InsereClienteNosDados(novoCliente);

                if (sucesso)
                {
                    Console.WriteLine("Cliente inserido com sucesso!");
                }
                else
                {
                    Console.WriteLine("Falha ao inserir o cliente.");
                }
            }
            catch (Exception ex)
            {
                // Captura exceções gerais
                Console.WriteLine($"Erro ao inserir cliente:  " + ex.Message);
            }

            try
            {
                // Criando um pedido com produto associado
                Pedido pedidoComProduto = new Pedido(1, "Notebook", "Diogo Abreu", "Pendente","11/11/2024",200, "Rua da felicidade");

                // Validando os pedidos
                bool pedidoValido = RegraPedido.ValidarPedidoNaoVazio(pedidoComProduto);

                if (pedidoValido)
                {
                    Console.WriteLine("Pedido inserido com sucesso!");
                }
                else
                {
                    Console.WriteLine("Falha ao inserir o Pedido.");
                }

            }
            catch (Exception ex)
            {
                // Tratamento de exceções inesperadas
                Console.WriteLine("Erro ao validar pedido: "+ex.Message);
            }

            try
            {
                // Criando instâncias de Produto para teste
                Produto produto3 = new Produto(1, "Mouse Gamer","AAAA",150,"Acessorio","Asus",20,24);


                Produto produto4 = new Produto(2, "Teclado Mecânico", "AAAA", -50, "Acessorio", "Asus", 20, 24);
 
                // Testando ValidarPrecoPositivo
                RegraProduto.ValidarPrecoPositivo(produto3);

                RegraProduto.ValidarPrecoPositivo(produto4);

                // Testando ValidarStock
                int quantidadeSolicitada = 10; // Teste com quantidade que excede o stock

                RegraProduto.ValidarStock(produto1, quantidadeSolicitada);

                RegraProduto.ValidarStock(produto2, quantidadeSolicitada);
            }
            catch (Exception ex)
            {
                // Tratamento de exceções inesperadas
                Console.WriteLine("Erro ao validar produto:"+ex.Message);
            }
            try
            {
                // Criando um utilizador válido
                Utilizador utilizadorValido = new Utilizador(1, "Ana Costa", "ana.costa@email.com", "978885222");

                // Tentando inserir o utilizador válido
                bool sucesso = RegraUtilizador.InsereUtilizadorNosDados(utilizadorValido);

            }
            catch (Exception ex)
            {
                // Captura exceções gerais, incluindo regras de negócio
                Console.WriteLine("Erro: "+ex.Message);
            }


            #endregion

            #region TestProject
            // Chama o método para rodar os testes (normalmente o MSTest faz isso automaticamente durante o build)
            var testClass = new UnitTest1();

            try
            {
                // Rodando o teste AtualizarEstadoEncomenda_DeveAtualizarEstadoCorretamente
                testClass.AtualizarEstadoEncomenda_DeveAtualizarEstadoCorretamente();

                // Rodando o teste CalcularValorComImposto_ComTaxaDe20PorCento_DeveRetornarValorCorreto
                testClass.CalcularValorComImposto_ComTaxaDe20PorCento_DeveRetornarValorCorreto();

                // Rodando o teste CalcularValorComImposto_ComTaxaDeZero_DeveRetornarMesmoValor
                testClass.CalcularValorComImposto_ComTaxaDeZero_DeveRetornarMesmoValor();

                // Rodando o teste AtualizarEstadoEncomenda_ComEstadoVazio_DeveManterEstadoAnterior
                testClass.AtualizarEstadoEncomenda_ComEstadoVazio_DeveManterEstadoAnterior();
            }
            catch (Exception ex)
            {
                // Caso algum erro aconteça, o teste falha
                Console.WriteLine("Erro durante a execução do teste:" +ex.Message);
            }
            #endregion

            Console.ReadKey();    

        }
    }
}
