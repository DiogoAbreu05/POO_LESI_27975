var searchData=
[
  ['email_0',['Email',['../class_business_object_1_1_cliente.html#abf62bb4a214c02189063c042b844a54b',1,'BusinessObject.Cliente.Email'],['../class_business_object_1_1_utilizador.html#a20dafdcab413bd802723c51bc05ef473',1,'BusinessObject.Utilizador.Email']]],
  ['endereco_1',['Endereco',['../class_business_object_1_1_cliente.html#a41cf76d61f40921d9780719f3e4d62a3',1,'BusinessObject::Cliente']]],
  ['estadodaencomenda_2',['EstadoDaEncomenda',['../class_business_object_1_1_pedido.html#a1a8bff977a7f1e7cdba0b78680197a73',1,'BusinessObject::Pedido']]]
];
