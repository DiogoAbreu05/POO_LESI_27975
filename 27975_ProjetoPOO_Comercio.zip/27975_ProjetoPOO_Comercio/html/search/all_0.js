var searchData=
[
  ['_2enetcoreapp_2cversion_3dv6_2e0_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v6.0.AssemblyAttributes.cs',['../_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html',1,'']]],
  ['_2enetframework_2cversion_3dv4_2e7_2e2_2eassemblyattributes_2ecs_1',['.NETFramework,Version=v4.7.2.AssemblyAttributes.cs',['../_business_object_lib_2obj_2_debug_2_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../_excecoes_lib_2obj_2_debug_2_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../_listas_lib_2obj_2_debug_2_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../obj_2_debug_2_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../_regras_lib_2obj_2_debug_2_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html',1,'(Global Namespace)']]]
];
