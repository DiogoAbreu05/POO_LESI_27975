var searchData=
[
  ['removerpedido_0',['RemoverPedido',['../class__27975___projeto_p_o_o___comercio_1_1_pedidos.html#ab1721f3d7cfb862bfd673f42ab192a68',1,'_27975_ProjetoPOO_Comercio::Pedidos']]]
];
