var searchData=
[
  ['desc_0',['Desc',['../namespace_business_object.html#a851dbd949fae82e95e33f54727287c27a5fc8b9a31666e95fddf7fdc19ba6070c',1,'BusinessObject']]]
];
