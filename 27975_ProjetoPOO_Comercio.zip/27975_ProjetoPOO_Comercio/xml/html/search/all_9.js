var searchData=
[
  ['ncontribuinte_0',['NContribuinte',['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#a7b02f26f605536144332d9c69aa7c31e',1,'_27975_ProjetoPOO_Comercio::Cliente']]],
  ['nivelacesso_1',['NivelAcesso',['../class__27975___projeto_p_o_o___comercio_1_1_admin.html#a8124bd2122817a5848423225296a440b',1,'_27975_ProjetoPOO_Comercio::Admin']]],
  ['nome_2',['Nome',['../class__27975___projeto_p_o_o___comercio_1_1_categoria.html#a62f8464addfb3fa2c5435c43ee952d9a',1,'_27975_ProjetoPOO_Comercio.Categoria.Nome'],['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#a6b3448b702513d4c5c8c7f2591dfd16b',1,'_27975_ProjetoPOO_Comercio.Cliente.Nome'],['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#a99fe446531fdde976783ba825e4f753a',1,'_27975_ProjetoPOO_Comercio.Produto.Nome'],['../class__27975___projeto_p_o_o___comercio_1_1_utilizador.html#a03e2e4abaeb29f287db61fb75531bb79',1,'_27975_ProjetoPOO_Comercio.Utilizador.Nome']]],
  ['ntelemovel_3',['NTelemovel',['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#a6b63d78b286c7bc33ad7d6d31bd0b4eb',1,'_27975_ProjetoPOO_Comercio.Cliente.NTelemovel'],['../class__27975___projeto_p_o_o___comercio_1_1_utilizador.html#a5d302b722a9904f27f39179b21a0c873',1,'_27975_ProjetoPOO_Comercio.Utilizador.NTelemovel']]]
];
