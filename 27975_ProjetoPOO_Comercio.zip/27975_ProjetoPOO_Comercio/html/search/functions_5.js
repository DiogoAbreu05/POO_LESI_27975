var searchData=
[
  ['mycompare_0',['MyCompare',['../class_business_object_1_1_my_compare.html#a4887051f2af4a3f63ae1ccfdae775460',1,'BusinessObject.MyCompare.MyCompare()'],['../class_business_object_1_1_my_compare.html#a7f880a372f41a76b2f29035bd6f181d4',1,'BusinessObject.MyCompare.MyCompare(SortDirecc dir)']]]
];
