using Microsoft.VisualStudio.TestTools.UnitTesting; 
using BusinessObject; 
namespace TestProject

{
    [TestClass]// Indica que esta classe cont�m m�todos de teste para serem executados pelo MSTest.
    public class UnitTest1
    {
        [TestMethod] // Indica que este m�todo � um teste unit�rio.
        public bool AtualizarEstadoEncomenda_DeveAtualizarEstadoCorretamente()
        {
            // Arrange: Configura o cen�rio de teste criando uma inst�ncia de Pedido e definindo o novo estado.
            // Cria uma inst�ncia do pedido com valores iniciais. e define o novo estado Pedido 
            var pedido = new Pedido(1, "Produto A", "Cliente A", "Pendente", "2024-12-13", 100, "Rua A"); 
            string novoEstado = "Enviado"; 

            // Act: Executa a a��o a ser testada, e chama o metodo para atualizar
            bool resultado = pedido.AtualizarEstadoEncomenda(novoEstado);

            // Assert: Verifica se os resultados da a��o est�o corretos.
            // Verifica se o m�todo retornou true, indicando sucesso.E Confirma o estado
            Assert.IsTrue(resultado); 
            Assert.AreEqual(novoEstado, pedido.EstadoDaEncomenda); 
                return true;
        }

        [TestMethod] // Indica que este m�todo � um teste unit�rio.
        public bool CalcularValorComImposto_ComTaxaDe20PorCento_DeveRetornarValorCorreto()
        {
            // Arrange: Configura o cen�rio de teste criando uma inst�ncia de Pedido e definindo a taxa de imposto.
            var pedido = new Pedido(1, "Produto A", "Cliente A", "Pendente", "2024-12-13", 100, "Rua A"); 
            double taxaImposto = 0.20; 
            int valorEsperado = 120; 

            // Act: Executa a a��o a ser testada.
            int valorComImposto = pedido.CalcularValorComImposto(taxaImposto); 

            // Assert: Verifica se os resultados da a��o est�o corretos.
            Assert.AreEqual(valorEsperado, valorComImposto); 
            return true;
        }

        [TestMethod]
        public bool CalcularValorComImposto_ComTaxaDeZero_DeveRetornarMesmoValor()
        {
            // Arrange: Configura o cen�rio de teste criando uma inst�ncia de Pedido e definindo a taxa de imposto como zero.
            var pedido = new Pedido(1, "Produto A", "Cliente A", "Pendente", "2024-12-13", 100, "Rua A"); 
            double taxaImposto = 0.0; 
            int valorEsperado = 100; 

            // Act: Executa a a��o a ser testada.
            int valorComImposto = pedido.CalcularValorComImposto(taxaImposto); 

            // Assert: Verifica se os resultados da a��o est�o corretos.
            Assert.AreEqual(valorEsperado, valorComImposto); 
            return true;
        }

        [TestMethod] 
        public bool AtualizarEstadoEncomenda_ComEstadoVazio_DeveManterEstadoAnterior()
        {
            // Arrange: Configura o cen�rio de teste criando uma inst�ncia de Pedido e definindo um estado vazio.
            var pedido = new Pedido(1, "Produto A", "Cliente A", "Pendente", "2024-12-13", 100, "Rua A"); 
            string estadoAnterior = pedido.EstadoDaEncomenda; 
            string novoEstado = string.Empty; 

            // Act: Executa a a��o a ser testada.
            pedido.AtualizarEstadoEncomenda(novoEstado); 

            // Assert: Verifica se os resultados da a��o est�o corretos.
            Assert.AreEqual(estadoAnterior, pedido.EstadoDaEncomenda);
            return true;
        }
    }
}
    
