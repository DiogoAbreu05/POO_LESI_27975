﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessObject
{
    public class Produto
    {
        #region Atributos
        // Classe Produto
        /// <summary>
        /// Representa um produto no sistema de comércio eletrônico.
        /// </summary>

            int id;
            string nome;
            string descricao;
             double preco;
            //Categoria Categoria;
            //Marca Marca;
            string categoria;
            string marca;
            int quantidadeEmStock;
            int garantiaMeses;

        
        #endregion

        #region Construtor
        /// <summary>
        /// Construtor padrão da classe Produto.
        /// </summary>
        public Produto(int id, string nome, string descricao, double preco, string categoria, string marca, int quantidadeEmStock, int garantiaMeses)
        {
            // Atribui o valor do parâmetro ao atributo correspondente da classe.
            this.id = id;
            this.nome = nome;
            this.descricao = descricao;
            this.preco = preco;
            this.categoria = categoria;
            this.marca = marca;
            this.quantidadeEmStock = quantidadeEmStock;
            this.garantiaMeses = garantiaMeses;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Região que agrupa as propriedades (getters e setters) da classe
        /// </summary>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }
        public double Preco
        {
            get { return preco; }
            set { preco = value; }
        }
        public string Categoria
        {
            get { return categoria; }
            set { categoria = value; }
        }
        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }
        public int QuantidadeEmStock
        {
            get { return quantidadeEmStock; }
            set { quantidadeEmStock = value; }
        }
        public int GarantiaMeses
        {
            get { return garantiaMeses; }
            set { garantiaMeses = value; }
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Atualiza a quantidade de stock
        /// </summary>
        /// <param name="quantidade"></param>
        public bool AtualizarStock(int quantidade)
        {
            quantidadeEmStock += quantidade;
            return true;
        }
       
        #endregion

    }
}
