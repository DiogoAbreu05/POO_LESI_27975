var searchData=
[
  ['marca_0',['Marca',['../class_business_object_1_1_produto.html#a8bff8b8e1287e1c04be7ae8609d21a35',1,'BusinessObject::Produto']]],
  ['moradaaenviar_1',['MoradaAEnviar',['../class_business_object_1_1_pedido.html#a3ef25b4ae8bbc7dca604fe58ae1396a0',1,'BusinessObject::Pedido']]],
  ['mycompare_2',['MyCompare',['../class_business_object_1_1_my_compare.html',1,'BusinessObject.MyCompare'],['../class_business_object_1_1_my_compare.html#a4887051f2af4a3f63ae1ccfdae775460',1,'BusinessObject.MyCompare.MyCompare()'],['../class_business_object_1_1_my_compare.html#a7f880a372f41a76b2f29035bd6f181d4',1,'BusinessObject.MyCompare.MyCompare(SortDirecc dir)']]],
  ['mycompare_2ecs_3',['MyCompare.cs',['../_my_compare_8cs.html',1,'']]]
];
