var searchData=
[
  ['email_0',['Email',['../class_business_object_1_1_cliente.html#abf62bb4a214c02189063c042b844a54b',1,'BusinessObject.Cliente.Email'],['../class_business_object_1_1_utilizador.html#a20dafdcab413bd802723c51bc05ef473',1,'BusinessObject.Utilizador.Email']]],
  ['endereco_1',['Endereco',['../class_business_object_1_1_cliente.html#a41cf76d61f40921d9780719f3e4d62a3',1,'BusinessObject::Cliente']]],
  ['estadodaencomenda_2',['EstadoDaEncomenda',['../class_business_object_1_1_pedido.html#a1a8bff977a7f1e7cdba0b78680197a73',1,'BusinessObject::Pedido']]],
  ['excecoeslib_3',['ExcecoesLib',['../namespace_excecoes_lib.html',1,'']]],
  ['existe_4',['Existe',['../class_listas_lib_1_1_clientes.html#a74518c696a1bbe944bb415f4137fc402',1,'ListasLib.Clientes.Existe()'],['../class_listas_lib_1_1_pedidos.html#a744b9e1d91ad8042f3b8efdaa3966a61',1,'ListasLib.Pedidos.Existe()'],['../class_listas_lib_1_1_produtos.html#a7088c74704e338cb12da9f700b27f219',1,'ListasLib.Produtos.Existe()'],['../class_listas_lib_1_1_utilizadores.html#a1f3687e6c27b1985e78d52abde9fbff3',1,'ListasLib.Utilizadores.Existe()']]]
];
