var searchData=
[
  ['marca_0',['Marca',['../class_business_object_1_1_produto.html#a8bff8b8e1287e1c04be7ae8609d21a35',1,'BusinessObject::Produto']]],
  ['moradaaenviar_1',['MoradaAEnviar',['../class_business_object_1_1_pedido.html#a3ef25b4ae8bbc7dca604fe58ae1396a0',1,'BusinessObject::Pedido']]]
];
