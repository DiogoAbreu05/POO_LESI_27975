var searchData=
[
  ['marca_0',['Marca',['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#a10877ee8882f5da2b42905e9a8a214ab',1,'_27975_ProjetoPOO_Comercio::Produto']]],
  ['moradaaenviar_1',['MoradaAEnviar',['../class__27975___projeto_p_o_o___comercio_1_1_pedido.html#ab77965930f2e86f07b5522d4edb9c91e',1,'_27975_ProjetoPOO_Comercio::Pedido']]],
  ['mostrarinformacoes_2',['MostrarInformacoes',['../class__27975___projeto_p_o_o___comercio_1_1_admin.html#a684d9f97dd8fdc702d5e223202adab48',1,'_27975_ProjetoPOO_Comercio.Admin.MostrarInformacoes()'],['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#a26a7b7e6743fb5b21d488b1aaa66041d',1,'_27975_ProjetoPOO_Comercio.Cliente.MostrarInformacoes()'],['../class__27975___projeto_p_o_o___comercio_1_1_utilizador.html#a37c0b1e197f3689a842c2bf74771638f',1,'_27975_ProjetoPOO_Comercio.Utilizador.MostrarInformacoes()']]]
];
