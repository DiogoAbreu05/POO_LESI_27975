var searchData=
[
  ['asc_0',['Asc',['../namespace_business_object.html#a851dbd949fae82e95e33f54727287c27ae8338cca05b6a68b1b516f4f0d6b0a0f',1,'BusinessObject']]]
];
