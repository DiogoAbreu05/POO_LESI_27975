var searchData=
[
  ['mycompare_0',['MyCompare',['../class_business_object_1_1_my_compare.html',1,'BusinessObject']]]
];
