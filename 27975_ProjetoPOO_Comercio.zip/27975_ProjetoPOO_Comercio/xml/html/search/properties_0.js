var searchData=
[
  ['categoria_0',['Categoria',['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#a69dbf0b7d8ad1efcc438f15174cd329d',1,'_27975_ProjetoPOO_Comercio::Produto']]],
  ['cliente_1',['Cliente',['../class__27975___projeto_p_o_o___comercio_1_1_pedido.html#a75d418b7e839ffea43948eb59dd9bfbd',1,'_27975_ProjetoPOO_Comercio::Pedido']]]
];
