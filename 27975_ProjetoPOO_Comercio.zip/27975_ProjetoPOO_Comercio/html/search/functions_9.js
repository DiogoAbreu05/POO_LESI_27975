var searchData=
[
  ['stockinsuficiente_0',['StockInsuficiente',['../class_excecoes_lib_1_1_stock_insuficiente.html#ad1fb0eb839ff786562888021d616f836',1,'ExcecoesLib.StockInsuficiente.StockInsuficiente()'],['../class_excecoes_lib_1_1_stock_insuficiente.html#ac3ef6af05e3e1d78faf68c62f3fb853b',1,'ExcecoesLib.StockInsuficiente.StockInsuficiente(string mensagem)'],['../class_excecoes_lib_1_1_stock_insuficiente.html#a1d95ef521c91f8a417ea0b35ae65109c',1,'ExcecoesLib.StockInsuficiente.StockInsuficiente(string mensagem, Exception inner)']]]
];
