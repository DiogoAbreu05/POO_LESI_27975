var searchData=
[
  ['email_0',['Email',['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#a8c6f0b94fed953cb76cb559b5fb210ff',1,'_27975_ProjetoPOO_Comercio.Cliente.Email'],['../class__27975___projeto_p_o_o___comercio_1_1_utilizador.html#a8a5ac5220030e2b67093cca87d94c621',1,'_27975_ProjetoPOO_Comercio.Utilizador.Email']]],
  ['endereco_1',['Endereco',['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#aaf1b6ee36adcb603e57fd53a107482dc',1,'_27975_ProjetoPOO_Comercio::Cliente']]],
  ['estadodaencomenda_2',['EstadoDaEncomenda',['../class__27975___projeto_p_o_o___comercio_1_1_pedido.html#a03adc658ec1896e35a3d759999a4e78c',1,'_27975_ProjetoPOO_Comercio::Pedido']]]
];
