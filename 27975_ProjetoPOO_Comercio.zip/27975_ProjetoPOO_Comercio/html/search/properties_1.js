var searchData=
[
  ['dataencomenda_0',['DataEncomenda',['../class_business_object_1_1_pedido.html#af550a2624b8d48238075167af6842e12',1,'BusinessObject::Pedido']]],
  ['descricao_1',['Descricao',['../class_business_object_1_1_produto.html#acf11dc72b5f843a593f3a15afd711cd7',1,'BusinessObject::Produto']]]
];
