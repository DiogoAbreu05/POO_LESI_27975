﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

using BusinessObject;

namespace ListasLib
{
    public class Clientes
    {
        #region Atributos
        /// <summary>
        /// Lista de clientes no sistema.
        /// </summary>
        private static List<Cliente> listaClientes;
        #endregion

        #region Construtor
        /// <summary>
        /// Construtor que inicia a lista de clientes.
        /// </summary>
        static Clientes()
        {
            listaClientes = new List<Cliente>();
        }
        #endregion

        #region Métodos
        /// <summary>
        /// Adiciona um novo cliente à lista.
        /// </summary>
        /// <param name="cliente">Objeto do tipo Cliente a ser adicionado.</param>
        public static bool AdicionarCliente(Cliente cliente)
        {
            try
            {
                listaClientes.Add(cliente);
                return true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
                return false;
            }
        }

        /// <summary>
        /// Remove um cliente da lista com base no ID.
        /// </summary>
        /// <param name="id">ID do cliente a ser removida.</param>
        public static bool RemoverCliente(int id)
        {
            // Procura a categoria com o ID especificado na lista.
            var categoria = listaClientes.Find(c => c.Id == id);

            // Se encontrada, remove; caso contrário, exibe uma mensagem.
            if (categoria != null)
            {
                listaClientes.Remove(categoria);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// Verifica se um cliente existe na lista pelo ID.
        /// </summary>
        /// <param name="id">ID da cliente.</param>
        /// <returns>Verdadeiro se a cliente existir; falso caso contrário.</returns>
        public static bool Existe(int id)
        {
            try
            {
                return listaClientes.Exists(c => c.Id == id);
                return true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
                return false;
            }
        }

        /// <summary>
        /// Guardar a lista de Clientes em um ficheiro.
        /// </summary>
        /// <param name="cdFile">Caminho do ficheiro onde os dados serão guardados.</param>
        public static void GuardarParaFicheiro(string cdFile)
        {
            // Cria um FileStream para manipular o ficheiro no caminho especificado
            FileStream f = new FileStream(@"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaClientes.bin", FileMode.Create);

            // Cria um BinaryFormatter para serializar os dados em formato binário
            BinaryFormatter b = new BinaryFormatter();

            // Serializa o objeto "listaClientes" e guarda no ficheiro
            b.Serialize(f, listaClientes);
        }

        /// <summary>
        /// Carrega a lista de clientes de um ficheiro.
        /// </summary>
        /// <param name="cdFile">Caminho do ficheiro a ser carregado.</param>
        public static void CarregarDeFicheiro(string cdFile)
        {
            // Cria um FileStream para ler o ficheiro no caminho especificado
            FileStream f = new FileStream(@"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaClientes.bin", FileMode.Open);

            // Cria um BinaryFormatter para desserializar os dados do ficheiro
            BinaryFormatter b = new BinaryFormatter();

            // Desserializa o conteúdo do ficheiro e atribui à variável "listaClientes"
            listaClientes = (List<Cliente>)b.Deserialize(f);
        }
        #endregion
    }
}
