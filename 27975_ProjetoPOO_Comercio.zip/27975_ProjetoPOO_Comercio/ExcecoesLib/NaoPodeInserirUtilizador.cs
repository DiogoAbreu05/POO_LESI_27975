﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcecoesLib
{
    public class NaoPodeInserirUtilizador: ApplicationException
    {

        /// <summary>
        /// Construtor padrão da exceção NaoPodeInserir.
        /// </summary>
        public NaoPodeInserirUtilizador() : base("Não foi possível inserir o item devido a uma regra de negócio.") { }

        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada.
        /// </summary>
        /// <param name="message">Mensagem de erro personalizada.</param>
        public NaoPodeInserirUtilizador(string message) : base(message) { }

        /// <summary>
        /// Construtor que permite passar uma mensagem personalizada e uma exceção interna.
        /// </summary>
        /// <param name="message">Mensagem de erro personalizada.</param>
        /// <param name="innerException">Exceção interna associada ao erro.</param>
        public NaoPodeInserirUtilizador(string message, Exception innerException) : base(message, innerException) { }
    }

}

