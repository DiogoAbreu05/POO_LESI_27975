﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    /// <summary>
    /// Auxiliar para Ordenação
    /// </summary>
    public enum SortDirecc
    {
        Asc, // Representa ordenação ascendente
        Desc // Representa ordenação descendente
    }

    /// <summary>
    /// Classe que implementa a interface IComparer para comparação personalizada
    /// </summary>
    public class MyCompare : IComparer
    {
        private SortDirecc dir; // Campo privado para armazenar a direção de ordenação

        /// <summary>
        /// Construtor padrão define a direção como ascendente
        /// </summary>
        public MyCompare()
        {
            dir = SortDirecc.Asc; 
        }

        /// <summary>
        /// Construtor que permite definir a direção de ordenação
        /// </summary>
        /// <param name="dir"></param>
        public MyCompare(SortDirecc dir)
        {
            this.dir = dir;  
        }

        /// <summary>
        /// Método que implementa a comparação
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public int Compare(object x, object y) 
        {
            // Verifica se algum dos objetos é nulo; se sim, considera-os iguais
            if (object.ReferenceEquals(x, null) || object.ReferenceEquals(y, null))
                return 0;

            // Caso os objetos sejam do tipo Cliente, compara seus nomes
            if (x is Cliente c1 && y is Cliente c2)
                return String.Compare(c1.Nome, c2.Nome) * (dir == SortDirecc.Asc ? 1 : -1);

            // Caso os objetos sejam do tipo Pedido, compara o valor da encomenda
            if (x is Pedido p1 && y is Pedido p2)
                return p1.ValorEncomenda.CompareTo(p2.ValorEncomenda) * (dir == SortDirecc.Asc ? 1 : -1);

            // Caso os objetos sejam do tipo Categoria, compara seus nomes
            if (x is Categoria cat1 && y is Categoria cat2)
                return String.Compare(cat1.Nome, cat2.Nome) * (dir == SortDirecc.Asc ? 1 : -1);

            // Retorna 0 para outros tipos de objetos não suportados
            return 0;
        }
    }

}
