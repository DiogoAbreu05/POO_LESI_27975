var searchData=
[
  ['quantidadeemstock_0',['QuantidadeEmStock',['../class_business_object_1_1_produto.html#ad5ce8f789282f3ab653c465f46bc9e69',1,'BusinessObject::Produto']]]
];
