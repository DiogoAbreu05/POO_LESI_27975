var searchData=
[
  ['utilizador_0',['Utilizador',['../class_business_object_1_1_utilizador.html#a63a595b50ac148bfa33362a0113a8858',1,'BusinessObject::Utilizador']]]
];
