﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using BusinessObject;
using ListasLib;
using ExcecoesLib;

namespace RegrasLib
{
    /// <summary>
    /// Classe que contém as regras de validação para os produtos.
    /// </summary>
    public class RegraProduto
    {
        /// <summary>
        /// Valida se o preço de um produto é positivo.
        /// </summary>
        /// <param name="produto"></param>
        /// <returns></returns>
        public static bool ValidarPrecoPositivo(Produto produto)
        {
            return produto.Preco > 0;
        }

        /// <summary>
        /// Valida se há Stock suficiente de um produto para uma quantidade solicitada.
        /// </summary>
        /// <param name="produto"></param>
        /// <param name="quantidade"></param>
        /// <returns></returns>
        public static bool ValidarStock(Produto produto, int quantidade)
        {
            return produto.QuantidadeEmStock >= quantidade;
        }
    }
}
