﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    // Subclasse Admin que herda de Utilizador
    public class Admin : Utilizador
    {
        #region Atributos
        // Classe 
        /// <summary>
        /// Representa um Admim no sistema de comércio eletrônico.
        /// </summary>

        int id;
        string nome;
        string email;
        string nivelAcesso;
        string nTelemovel;
        #endregion

        #region Properties

        /// <summary>
        /// Região que agrupa as propriedades (getters e setters) da classe
        /// </summary>
        public string NivelAcesso
        {
            get { return nivelAcesso; }
            set { nivelAcesso = value; }
        }
        #endregion

        #region Construtor
        /// <summary>
        /// Construtor da classe Admin que chama o construtor da base
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nome"></param>
        /// <param name="email"></param>
        /// <param name="nivelAcesso"></param>
        public Admin(int id, string nome, string email, string nivelAcesso)
                : base(id, nome, email, nivelAcesso) // Chamada ao construtor da classe base
        {
            NivelAcesso = nivelAcesso; // Atribui o nível de acesso
        }
        #endregion
    }
    
}
