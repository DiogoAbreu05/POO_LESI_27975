var searchData=
[
  ['id_0',['Id',['../class__27975___projeto_p_o_o___comercio_1_1_categoria.html#ab0e4749ef5077082c571b56c34c460ad',1,'_27975_ProjetoPOO_Comercio.Categoria.Id'],['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#a42fce25cb417e92428753c29a2fb33e5',1,'_27975_ProjetoPOO_Comercio.Cliente.Id'],['../class__27975___projeto_p_o_o___comercio_1_1_pedido.html#a92fc25de707afbcce2987d6ec089769a',1,'_27975_ProjetoPOO_Comercio.Pedido.Id'],['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#a5049748ec081f9d5c1c9cbf08ee8f2b3',1,'_27975_ProjetoPOO_Comercio.Produto.Id'],['../class__27975___projeto_p_o_o___comercio_1_1_utilizador.html#a81bec2129b6b5250fb13f7639afa5c01',1,'_27975_ProjetoPOO_Comercio.Utilizador.Id']]]
];
