var searchData=
[
  ['testproject_2eassemblyinfo_2ecs_0',['TestProject.AssemblyInfo.cs',['../_test_project_8_assembly_info_8cs.html',1,'']]],
  ['testproject_2eglobalusings_2eg_2ecs_1',['TestProject.GlobalUsings.g.cs',['../_test_project_8_global_usings_8g_8cs.html',1,'']]]
];
