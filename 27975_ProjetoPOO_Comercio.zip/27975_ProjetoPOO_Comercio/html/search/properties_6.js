var searchData=
[
  ['ncontribuinte_0',['NContribuinte',['../class_business_object_1_1_cliente.html#aa35087c94bf9aa95183e7e5c4e5ea52d',1,'BusinessObject::Cliente']]],
  ['nivelacesso_1',['NivelAcesso',['../class_business_object_1_1_admin.html#a6e0c681d7700cf38c9ae28c44cd9d922',1,'BusinessObject::Admin']]],
  ['nome_2',['Nome',['../class_business_object_1_1_categoria.html#aac77fd04f3c7be1557df6377e2c7c653',1,'BusinessObject.Categoria.Nome'],['../class_business_object_1_1_cliente.html#a672f24b234d07a48f1edcdf4eb8afd94',1,'BusinessObject.Cliente.Nome'],['../class_business_object_1_1_produto.html#af231c36c718115d18c5515aebd3ed9ef',1,'BusinessObject.Produto.Nome'],['../class_business_object_1_1_utilizador.html#acb90639c0945c2839417c968bb610e2a',1,'BusinessObject.Utilizador.Nome']]],
  ['ntelemovel_3',['NTelemovel',['../class_business_object_1_1_cliente.html#ae766a758149f41b2861338f61f4f1cb0',1,'BusinessObject.Cliente.NTelemovel'],['../class_business_object_1_1_utilizador.html#af0b626e983278a95d8e7f043699159da',1,'BusinessObject.Utilizador.NTelemovel']]]
];
