var searchData=
[
  ['utilizador_0',['Utilizador',['../class__27975___projeto_p_o_o___comercio_1_1_utilizador.html#aaf2806d0e50d2ae1b985af814af519c8',1,'_27975_ProjetoPOO_Comercio::Utilizador']]],
  ['utilizadores_1',['Utilizadores',['../class__27975___projeto_p_o_o___comercio_1_1_utilizadores.html#a3b12dee0e8f3949272f9db0fcf165fb6',1,'_27975_ProjetoPOO_Comercio::Utilizadores']]]
];
