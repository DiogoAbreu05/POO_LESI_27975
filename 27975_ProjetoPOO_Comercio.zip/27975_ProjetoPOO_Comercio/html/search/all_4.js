var searchData=
[
  ['calcularvalorcomimposto_0',['CalcularValorComImposto',['../class_business_object_1_1_pedido.html#a029c49f1ef2f5fd019c08d4177e2d931',1,'BusinessObject::Pedido']]],
  ['calcularvalorcomimposto_5fcomtaxade20porcento_5fdeveretornarvalorcorreto_1',['CalcularValorComImposto_ComTaxaDe20PorCento_DeveRetornarValorCorreto',['../class_test_project_1_1_unit_test1.html#a68d0986c1d4ca92d485bcdd3e5fe29ad',1,'TestProject::UnitTest1']]],
  ['calcularvalorcomimposto_5fcomtaxadezero_5fdeveretornarmesmovalor_2',['CalcularValorComImposto_ComTaxaDeZero_DeveRetornarMesmoValor',['../class_test_project_1_1_unit_test1.html#adae8714a644d2e728b8878db80d22e53',1,'TestProject::UnitTest1']]],
  ['carregardeficheiro_3',['CarregarDeFicheiro',['../class_listas_lib_1_1_clientes.html#a24c7ed24f2401e992c89f649ebb90553',1,'ListasLib.Clientes.CarregarDeFicheiro()'],['../class_listas_lib_1_1_pedidos.html#aa9c9c6076d8609bda3eeb624dc19cfee',1,'ListasLib.Pedidos.CarregarDeFicheiro()'],['../class_listas_lib_1_1_produtos.html#a3085413829ccf42a38437a0eaa29c89f',1,'ListasLib.Produtos.CarregarDeFicheiro()'],['../class_listas_lib_1_1_utilizadores.html#a5671c3dbc011a5e2f6cbcc1ee698a937',1,'ListasLib.Utilizadores.CarregarDeFicheiro()']]],
  ['categoria_4',['Categoria',['../class_business_object_1_1_categoria.html',1,'BusinessObject.Categoria'],['../class_business_object_1_1_produto.html#ab503b0b160827cf1e39245b196190c73',1,'BusinessObject.Produto.Categoria'],['../class_business_object_1_1_categoria.html#ac687cb97a8b64447040ce40c8271b169',1,'BusinessObject.Categoria.Categoria()']]],
  ['categoria_2ecs_5',['Categoria.cs',['../_categoria_8cs.html',1,'']]],
  ['categorias_2ecs_6',['Categorias.cs',['../_categorias_8cs.html',1,'']]],
  ['cliente_7',['Cliente',['../class_business_object_1_1_cliente.html',1,'BusinessObject.Cliente'],['../class_business_object_1_1_pedido.html#a8ad91cb48728e9711e5a02e31bec4049',1,'BusinessObject.Pedido.Cliente'],['../class_business_object_1_1_cliente.html#a10d249bce470e884916bbee7eba9f456',1,'BusinessObject.Cliente.Cliente()']]],
  ['cliente_2ecs_8',['Cliente.cs',['../_cliente_8cs.html',1,'']]],
  ['clientenaoencontrado_9',['ClienteNaoEncontrado',['../class_excecoes_lib_1_1_cliente_nao_encontrado.html',1,'ExcecoesLib.ClienteNaoEncontrado'],['../class_excecoes_lib_1_1_cliente_nao_encontrado.html#a20c578a29180eadbf73ac35f9e436788',1,'ExcecoesLib.ClienteNaoEncontrado.ClienteNaoEncontrado()'],['../class_excecoes_lib_1_1_cliente_nao_encontrado.html#a7162333bc0d955f950e713553f418dc9',1,'ExcecoesLib.ClienteNaoEncontrado.ClienteNaoEncontrado(string mensagem)'],['../class_excecoes_lib_1_1_cliente_nao_encontrado.html#a1e64514cb05377cee74de6245a493f3d',1,'ExcecoesLib.ClienteNaoEncontrado.ClienteNaoEncontrado(string mensagem, Exception inner)']]],
  ['clientenaoencontrado_2ecs_10',['ClienteNaoEncontrado.cs',['../_cliente_nao_encontrado_8cs.html',1,'']]],
  ['clientes_11',['Clientes',['../class_listas_lib_1_1_clientes.html',1,'ListasLib']]],
  ['clientes_2ecs_12',['Clientes.cs',['../_clientes_8cs.html',1,'']]],
  ['compare_13',['Compare',['../class_business_object_1_1_my_compare.html#a643e9b8ad580cfc819d28c630512635a',1,'BusinessObject::MyCompare']]]
];
