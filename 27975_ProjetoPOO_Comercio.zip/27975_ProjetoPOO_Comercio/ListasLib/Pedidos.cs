﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

using BusinessObject;

namespace ListasLib
{
    public class Pedidos
    {
        #region Atributos
        /// <summary>
        /// Lista de pedidos no sistema.
        /// </summary>
        private static List<Pedido> listaPedidos;
        #endregion

        #region Construtor
        /// <summary>
        /// Construtor que inicia a lista de pedidos.
        /// </summary>
         static Pedidos()
        {
            listaPedidos = new List<Pedido>();
        }
        #endregion

        #region Métodos
        /// <summary>
        /// Adiciona um novo pedido à lista.
        /// </summary>
        /// <param name="pedido">Objeto do tipo Pedido a ser adicionado.</param>
        public static bool AdicionarPedido(Pedido pedido)
        {
            try
            {
                listaPedidos.Add(pedido);
                return true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
                return false;
            }
        }

        /// <summary>
        /// Remove um Pedido da lista com base no ID.
        /// </summary>
        /// <param name="id">ID do pedido a ser removida.</param>
        public  static bool RemoverPedidos(int id)
        {
            // Procura a categoria com o ID especificado na lista.
            var categoria = listaPedidos.Find(c => c.Id == id);

            // Se encontrada, remove; caso contrário, exibe uma mensagem.
            if (categoria != null)
            {
                listaPedidos.Remove(categoria);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// Verifica se um pedido existe na lista pelo ID.
        /// </summary>
        /// <param name="id">ID Pedido.</param>
        /// <returns>Verdadeiro se o pedido existir; falso caso contrário.</returns>
        public static bool Existe(int id)
        {
            try
            {
                return listaPedidos.Exists(c => c.Id == id);
                return true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
                return false;
            }
        }

        /// <summary>
        /// Guardar a lista de pedidos em um ficheiro.
        /// </summary>
        /// <param name="cdFile">Caminho do ficheiro onde os dados serão guardados.</param>
        public static void GuardarParaFicheiro(string cdFile)
        {
            // Cria um FileStream para manipular o ficheiro no caminho especificado
            FileStream f = new FileStream(@"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaPedidos.bin", FileMode.Create);

            // Cria um BinaryFormatter para serializar os dados em formato binário
            BinaryFormatter b = new BinaryFormatter();

            // Serializa o objeto "listaPedidos" e guarda no ficheiro
            b.Serialize(f, listaPedidos);
        }

        /// <summary>
        /// Carrega a lista de pedidos de um ficheiro.
        /// </summary>
        /// <param name="cdFile">Caminho do ficheiro a ser carregado.</param>
        public static void CarregarDeFicheiro(string cdFile)
        {
            // Cria um FileStream para ler o ficheiro no caminho especificado
            FileStream f = new FileStream(@"C:\IPCA\POO\27975_ProjetoPOO_Comercio\listaPedidos.bin", FileMode.Open);

            // Cria um BinaryFormatter para desserializar os dados do ficheiro
            BinaryFormatter b = new BinaryFormatter();

            // Desserializa o conteúdo do ficheiro e atribui à variável "listaPedidos"
            listaPedidos = (List<Pedido>)b.Deserialize(f);

        }
        #endregion
    }
}
