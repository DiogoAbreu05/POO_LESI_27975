var searchData=
[
  ['removercategoria_0',['RemoverCategoria',['../class_listas_lib_1_1_produtos.html#a90ab2607196f1b440e3d264abc4ec362',1,'ListasLib.Produtos.RemoverCategoria()'],['../class_listas_lib_1_1_utilizadores.html#a8acf1eb769e7c46fd150c0e49d5952aa',1,'ListasLib.Utilizadores.RemoverCategoria()']]],
  ['removercliente_1',['RemoverCliente',['../class_listas_lib_1_1_clientes.html#a77c7fe83036ad840113a5743e4380927',1,'ListasLib::Clientes']]],
  ['removerpedidos_2',['RemoverPedidos',['../class_listas_lib_1_1_pedidos.html#a087c322d909300ace59fb42de9bc59ba',1,'ListasLib::Pedidos']]]
];
