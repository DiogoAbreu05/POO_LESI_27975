var searchData=
[
  ['categoria_0',['Categoria',['../class_business_object_1_1_produto.html#ab503b0b160827cf1e39245b196190c73',1,'BusinessObject::Produto']]],
  ['cliente_1',['Cliente',['../class_business_object_1_1_pedido.html#a8ad91cb48728e9711e5a02e31bec4049',1,'BusinessObject::Pedido']]]
];
