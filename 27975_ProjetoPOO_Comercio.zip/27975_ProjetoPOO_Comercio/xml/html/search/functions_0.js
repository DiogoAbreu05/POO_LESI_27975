var searchData=
[
  ['adicionarcategoria_0',['AdicionarCategoria',['../class__27975___projeto_p_o_o___comercio_1_1_categorias.html#a1383c3c779d6f5a5610ad68593ef6caa',1,'_27975_ProjetoPOO_Comercio::Categorias']]],
  ['adicionarcliente_1',['AdicionarCliente',['../class__27975___projeto_p_o_o___comercio_1_1_clientes.html#ae5dbc29654f3b9fd9e79ba54ce979474',1,'_27975_ProjetoPOO_Comercio::Clientes']]],
  ['adicionarpedido_2',['AdicionarPedido',['../class__27975___projeto_p_o_o___comercio_1_1_pedidos.html#a93f83472acfb1a39140bfa861116ecca',1,'_27975_ProjetoPOO_Comercio::Pedidos']]],
  ['adicionarproduto_3',['AdicionarProduto',['../class__27975___projeto_p_o_o___comercio_1_1_produtos.html#a407969a542ee007e78a5916c10e040b1',1,'_27975_ProjetoPOO_Comercio::Produtos']]],
  ['adicionarutilizador_4',['AdicionarUtilizador',['../class__27975___projeto_p_o_o___comercio_1_1_utilizadores.html#acdf5ba65b3c6da3b421fc46fa214cc2f',1,'_27975_ProjetoPOO_Comercio::Utilizadores']]],
  ['admin_5',['Admin',['../class__27975___projeto_p_o_o___comercio_1_1_admin.html#a5e195563ca4192ad36ee2e340dfefd12',1,'_27975_ProjetoPOO_Comercio::Admin']]],
  ['atualizarcontato_6',['AtualizarContato',['../class__27975___projeto_p_o_o___comercio_1_1_cliente.html#a7071df0c410febe482ac858d926744e9',1,'_27975_ProjetoPOO_Comercio::Cliente']]],
  ['atualizarestadoencomenda_7',['AtualizarEstadoEncomenda',['../class__27975___projeto_p_o_o___comercio_1_1_pedido.html#ae81adc824d575692a2142390c05049b6',1,'_27975_ProjetoPOO_Comercio::Pedido']]],
  ['atualizarnome_8',['AtualizarNome',['../class__27975___projeto_p_o_o___comercio_1_1_categoria.html#a411b113a934916abb4920cae5d58594c',1,'_27975_ProjetoPOO_Comercio::Categoria']]],
  ['atualizarstock_9',['AtualizarStock',['../class__27975___projeto_p_o_o___comercio_1_1_produto.html#a003144bcaedc068519aaac733d3bbc2d',1,'_27975_ProjetoPOO_Comercio::Produto']]]
];
